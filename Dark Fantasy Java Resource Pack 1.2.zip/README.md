# Dark Realism Resource Pack

This project uses fishbuild for compilation.

`fishbuild run dev` to run a dev compilation.